﻿namespace NativeUI
{
    public interface IListItem
    {
        string CurrentItem();
    }
}